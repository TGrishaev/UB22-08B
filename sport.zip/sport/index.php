<?php
session_start();
include "header.php";
header("Location: view_sports.php");
exit();
?>